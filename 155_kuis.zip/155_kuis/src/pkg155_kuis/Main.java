
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Main extends JFrame {
    private JFrame frame;
    private JTextField txtNama, txtSekolah;
    private JRadioButton[]opsi;
    private ButtonGroup btnGroup;
    private JButton btnSave;
    private String[]categori = {"Animasi","Menulis Surat"};
    private String select;
    public Main(){
        frame = new JFrame("Lomba");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400,300);
        frame.setLayout(new BorderLayout());
        selectPanel();
        frame.setVisible(true);
    }
    private void selectPanel(){
        JPanel panel = new JPanel(new GridLayout(2,1));
        JLabel lblJudul = new JLabel("Kategori Lomba");
        panel.add(lblJudul);
        JPanel btnPanel = new JPanel();
        opsi = new JRadioButton[categori.length];
        btnGroup = new ButtonGroup();
        for(int i=0; i<categori.length; i++){
            opsi[i] = new JRadioButton(categori[i]);
            int finalI = i;
            opsi[i].addActionListener(new ActionListener(){
                
                public void actionPerformed(ActionEvent e){
                    select = categori[finalI];
                    createDetailPanel();
                }
            });
            btnGroup.add(opsi[i]);
            btnPanel.add(opsi[i]);
        }
        panel.add(btnPanel);
        frame.add(panel, BorderLayout.CENTER);
    }
    private void createDetailPanel(){
        JPanel panel= new JPanel(new GridLayout(5,2));
        panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel radioPanel = new JPanel(new GridLayout(1, categori.length));
        if(select.equals("Animasi")){
            panel.add(new JLabel ("nama"));
            txtNama = new JTextField();
            panel.add(txtNama);
            
            panel.add(new JLabel ("Sekolah"));
            txtSekolah = new JTextField();
            panel.add(txtSekolah);
        }else if (select.equals("Menulis Surat")){
            panel.add(new JLabel ("nama"));
            txtNama = new JTextField();
            panel.add(txtNama);
            
            panel.add(new JLabel ("Sekolah"));
            txtSekolah = new JTextField();
            panel.add(txtSekolah);
        }
        btnSave=new JButton("Simpan");
        panel.add(btnSave);
        frame.getContentPane().removeAll();
        frame.add(panel,BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
    }
    public static void main(String[] args){
        
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                new Main();
            }
        });
    }
    
}
